import requests
import json

print("🔎 PhoneHunter - OSINT Pencarian Publik")
print("========================================")

def search_username(username):
    platforms = {
        "Twitter": f"https://twitter.com/{username}",
        "Instagram": f"https://www.instagram.com/{username}/",
        "Telegram": f"https://t.me/{username}"
    }
    print(f"\n📱 Mencari username: {username}")
    for platform, url in platforms.items():
        response = requests.get(url)
        if response.status_code == 200:
            print(f"✅ Ditemukan di {platform}: {url}")
        else:
            print(f"❌ Tidak ditemukan di {platform}")

def search_phone(phone):
    print(f"\n📞 Pencarian publik nomor: {phone}")
    print("🔗 Contoh pencarian manual:")
    print(f"https://www.google.com/search?q=\"{phone}\"")
    print(f"https://www.truecaller.com/search/id/{phone}")

def search_email(email):
    print(f"\n📧 Pencarian publik email: {email}")
    print("🔗 Contoh pencarian manual:")
    print(f"https://www.google.com/search?q=\"{email}\"")

def search_name(name):
    print(f"\n🧑 Pencarian publik nama: {name}")
    print("🔗 Contoh pencarian manual:")
    print(f"https://www.google.com/search?q=\"{name}\"")

# Contoh penggunaan
if __name__ == "__main__":
    username = input("Masukkan username: ")
    search_username(username)

    phone = input("\nMasukkan nomor telepon: ")
    search_phone(phone)

    email = input("\nMasukkan email: ")
    search_email(email)

    name = input("\nMasukkan nama: ")
    search_name(name)
