# PhoneHunter

PhoneHunter adalah alat OSINT sederhana untuk mencari data publik berdasarkan:
- Username sosial media (Twitter, Instagram, Telegram, dll)
- Nomor telepon (pencarian publik)
- Email publik
- Nama publik

## 🔧 Cara Menjalankan (di Codespaces)
1. Buka terminal Codespaces
2. Jalankan:
   ```bash
   pip install -r requirements.txt
   python search_osint.py
   ```

## ⚠️ Catatan
Alat ini hanya mencari **data publik** dan tidak mengakses atau menampilkan data pribadi.
Gunakan secara etis dan sesuai hukum yang berlaku.
